# Aplikasi android webView - React Native

Aplikasi lanjutan untuk absensi dengan Google Apps Script.
Membuat aplikasi android webView dengan react native.
- Akses lokasi (geolocation)
- Menghapus banner google

## Video tutorial
[![DEMO](http://img.youtube.com/vi/jl2anXE-ixY/0.jpg)](https://youtu.be/jl2anXE-ixY)

## Donasi  
Dukung saya 
- [Traktir kopi](https://sociabuzz.com/fahroniganteng/tribe)
- [atau Es krim](https://trakteer.id/fahroniganteng/tip) 
